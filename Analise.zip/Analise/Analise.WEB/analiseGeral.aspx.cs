﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Analise.DTL;
using Analise.BLL;

namespace Analise.WEB
{
    public partial class analiseGeral : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                gdvAnalises.DataSource = new AnaliseBO().ListarAnalisesGrid();
                gdvAnalises.DataBind();
            }
        }

        protected void lkbAnaliseGrid_Click(object sender, EventArgs e)
        {
            int id = int.Parse(((LinkButton)sender).CommandArgument);

            AnaliseDTO analise = new AnaliseBO().RetornarAnalise(id);

            pnAnaliseGeral.Visible = true;
            lblAnalise.Text = "Analise numero: " + id.ToString("00000");

            #region Montagem do CheckList

            List<CheckListGrupoDTO> checkList = new AnaliseBO().ListarCheckList(analise);

            Session.Add("checklist", checkList);

            lblCheckList.Text = new AnaliseBO().MontagemExibicaoCheckList(checkList);

            #endregion

            #region Montagem da Ficha Cadastral

            lblFichaCadastralCNPJ.Text = analise.CNPJ;
            lblFichaCadastralDataAnalise.Text = analise.DataAnalise.ToString("dd/MM/yyyy");
            lblFichaCadastralEndereco.Text = analise.Endereco;
            lblFichaCadastralId.Text = analise.IdAnalise.ToString();
            lblFichaCadastralRazaoSocial.Text = analise.RazaoSocial;
            lblFichaCadastralStatus.Text = analise.Status;
            lblFichaCadastralTelefone.Text = analise.Telefone;

            lblFichaCadastralBanco.Text = analise.Banco;
            lblFichaCadastralAgencia.Text = analise.Agencia;
            lblFichaCadastralConta.Text = analise.Conta;

            lblFichaCadastralRGMaster.Text = analise.RGMaster;
            lblFichaCadastralCPFMaster.Text = analise.CPFMaster;
            lblFichaCadastralUsuarioMaster.Text = analise.UsuarioMaster;

            gdvResponsaveis.DataSource = analise.ListaResponsavel;
            gdvResponsaveis.DataBind();


            gdvAutorizado.DataSource = analise.ListaAutorizado;
            gdvAutorizado.DataBind();

            #endregion

            #region Montagem de Grid de Arquivos

            lblStatusMinutaContrato.Text = new AnaliseBO().VerificarMinutaContrato(id);

            gdvArquivos.DataSource = new AnaliseBO().ListarArquivos(id);
            gdvArquivos.DataBind();

            #endregion

            #region Preechimento do Histórico do Parecer


            #endregion

        }

        protected void gdvAnalises_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType.Equals(DataControlRowType.DataRow))
            {
                Label lblItemGrid = (Label)e.Row.FindControl("lblAnaliseGrid");
                LinkButton lbkAnalise = (LinkButton)e.Row.FindControl("lkbAnaliseGrid");

                lblItemGrid.Text = e.Row.DataItem.ToString().Split('|')[0];
                lbkAnalise.CommandArgument = e.Row.DataItem.ToString().Split('|')[1];

                e.Row.CssClass = e.Row.DataItem.ToString().Split('|')[2];
            }
        }

        #region CheckList

        private void AlterarCheckList(bool check, int grupo, int item)
        {
            List<CheckListGrupoDTO> checkList = (List<CheckListGrupoDTO>)Session["checklist"];

            checkList[grupo].ListaItens[item].Resultado = (check) ? EnumResultadoAnalise.Aprovado : EnumResultadoAnalise.Reprovado;


            Session["checklist"] = checkList;

            lblCheckList.Text = new AnaliseBO().MontagemExibicaoCheckList(checkList);

        }

        #region Ficha Cadastral

        #region A ficha cadastral devidamente preenchida

        protected void chkCheckListFicha01Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha01Reprovado.Checked = !chkCheckListFicha01Aprovado.Checked;

            if (chkCheckListFicha01Aprovado.Checked)
            {
                AlterarCheckList(true, 0, 0);
            }
        }

        protected void chkCheckListFicha01Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha01Aprovado.Checked = !chkCheckListFicha01Reprovado.Checked;

            if (chkCheckListFicha01Reprovado.Checked)
            {
                AlterarCheckList(false, 0, 0);
            }

        }

        #endregion

        #region CNPJ sem restrições

        protected void chkCheckListFicha02Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha02Reprovado.Checked = !chkCheckListFicha02Aprovado.Checked;

            if (chkCheckListFicha02Aprovado.Checked)
            {
                AlterarCheckList(true, 0, 1);
            }
        }

        protected void chkCheckListFicha02Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha02Aprovado.Checked = !chkCheckListFicha02Reprovado.Checked;

            if (chkCheckListFicha02Reprovado.Checked)
            {
                AlterarCheckList(false, 0, 1);
            }
        }

        #endregion

        #region Telefone informado valido

        protected void chkCheckListFicha03Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha03Reprovado.Checked = !chkCheckListFicha03Aprovado.Checked;

            if (chkCheckListFicha03Aprovado.Checked)
            {
                AlterarCheckList(true, 0, 2);
            }
        }

        protected void chkCheckListFicha03Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha03Aprovado.Checked = !chkCheckListFicha03Reprovado.Checked;

            if (chkCheckListFicha03Reprovado.Checked)
            {
                AlterarCheckList(false, 0, 2);
            }
        }

        #endregion

        #region Dados bancarios confirmados

        protected void chkCheckListFicha04Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha04Reprovado.Checked = !chkCheckListFicha04Aprovado.Checked;

            if (chkCheckListFicha04Aprovado.Checked)
            {
                AlterarCheckList(true, 0, 3);
            }
        }

        protected void chkCheckListFicha04Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha04Aprovado.Checked = !chkCheckListFicha04Reprovado.Checked;

            if (chkCheckListFicha04Reprovado.Checked)
            {
                AlterarCheckList(false, 0, 3);
            }
        }

        #endregion

        #region Responsaveis legais sem restrições

        protected void chkCheckListFicha05Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha05Reprovado.Checked = !chkCheckListFicha05Aprovado.Checked;

            if (chkCheckListFicha05Aprovado.Checked)
            {
                AlterarCheckList(true, 0, 4);
            }
        }

        protected void chkCheckListFicha05Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha05Aprovado.Checked = !chkCheckListFicha05Reprovado.Checked;

            if (chkCheckListFicha05Reprovado.Checked)
            {
                AlterarCheckList(false, 0, 4);
            }
        }

        #endregion

        #region Usuario master validado no sistema

        protected void chkCheckListFicha06Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha06Reprovado.Checked = !chkCheckListFicha06Aprovado.Checked;

            if (chkCheckListFicha06Aprovado.Checked)
            {
                AlterarCheckList(true, 0, 5);
            }
        }

        protected void chkCheckListFicha06Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkCheckListFicha06Aprovado.Checked = !chkCheckListFicha06Reprovado.Checked;

            if (chkCheckListFicha06Reprovado.Checked)
            {
                AlterarCheckList(false, 0, 5);
            }
        }

        #endregion

        #endregion

        #region Documentos

        #region Documentos enviados visiveis

        protected void chkDocumentos01Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos01Reprovado.Checked = !chkDocumentos01Aprovado.Checked;

            if (chkDocumentos01Aprovado.Checked)
            {
                AlterarCheckList(true, 1, 0);
            }
        }


        protected void chkDocumentos01Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos01Aprovado.Checked = !chkDocumentos01Reprovado.Checked;

            if (chkDocumentos01Reprovado.Checked)
            {
                AlterarCheckList(false, 1, 0);
            }
        }

        #endregion

        #region Documentos de todos os responsaveis enviados

        protected void chkDocumentos02Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos02Reprovado.Checked = !chkDocumentos02Aprovado.Checked;

            if (chkDocumentos02Aprovado.Checked)
            {
                AlterarCheckList(true, 1, 1);
            }
        }

        protected void chkDocumentos02Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos02Aprovado.Checked = !chkDocumentos02Reprovado.Checked;

            if (chkDocumentos02Reprovado.Checked)
            {
                AlterarCheckList(false, 1, 1);
            }
        }

        #endregion

        #region Documentos não apresentão rasuras

        protected void chkDocumentos03Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos03Reprovado.Checked = !chkDocumentos03Aprovado.Checked;

            if (chkDocumentos03Aprovado.Checked)
            {
                AlterarCheckList(false, 1, 2);
            }
        }

        protected void chkDocumentos03Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos03Aprovado.Checked = !chkDocumentos03Reprovado.Checked;

            if (chkDocumentos03Reprovado.Checked)
            {
                AlterarCheckList(false, 1, 2);
            }
        }

        #endregion

        #region Documentos validos

        protected void chkDocumentos04Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos04Reprovado.Checked = !chkDocumentos04Aprovado.Checked;

            if (chkDocumentos04Aprovado.Checked)
            {
                AlterarCheckList(true, 1, 3);
            }
        }

        protected void chkDocumentos04Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkDocumentos04Aprovado.Checked = !chkDocumentos04Reprovado.Checked;

            if (chkDocumentos04Reprovado.Checked)
            {
                AlterarCheckList(false, 1, 3);
            }
        }

        #endregion

        #endregion

        #region Minuta de Contrato 

        #region Minuta de Contrato Validada

        protected void chkMinuta01Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkMinuta01Reprovado.Checked = !chkMinuta01Aprovado.Checked;

            if (chkMinuta01Aprovado.Checked)
            {
                AlterarCheckList(true, 2, 1);
            }
        }

        protected void chkMinuta01Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkMinuta01Aprovado.Checked = !chkMinuta01Reprovado.Checked;

            if (chkMinuta01Reprovado.Checked)
            {
                AlterarCheckList(false, 2, 0);
            }
        }

        #endregion

        #region Minuta Devidamente Assinada

        protected void chkMinuta02Aprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkMinuta02Reprovado.Checked = !chkMinuta02Aprovado.Checked;

            if (chkMinuta02Aprovado.Checked)
            {
                AlterarCheckList(true, 2, 1);
            }
        }

        protected void chkMinuta02Reprovado_CheckedChanged(object sender, EventArgs e)
        {
            chkMinuta02Aprovado.Checked = !chkMinuta02Reprovado.Checked;

            if (chkMinuta02Reprovado.Checked)
            {
                AlterarCheckList(false, 2, 1);
            }
        }

        #endregion

        #endregion 

        #endregion

        protected void btnFinalisar_Click(object sender, EventArgs e)
        {
            pnModalFinalizar_ModalPopupExtender.Show();
        }

        protected void imbSalvar_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void imbEscalar_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}