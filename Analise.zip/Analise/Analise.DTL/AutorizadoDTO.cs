﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Analise.DTL
{
    public class AutorizadoDTO
    {
        public string Nome { get; set; }
        public string CPF { get; set; }
        public string RG { get; set; }
    }
}
