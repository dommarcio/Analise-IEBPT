﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Analise.DTL
{
    public class ArquivoDTL
    {
        public string NomeArquivo { get; set; }
        public string TipoArquivo { get; set; }
        public string StrTamanho { get; set; }
        public byte[] BitsArquivo { get; set; }
        public string TipoReferencia { get; set; }
        public string Caminho { get; set; }
    }

}
