﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Analise.DTL
{
    public enum EnumResultadoAnalise
    {
        EmAnalise = 1,
        Reprovado,
        Aprovado
    }
}
